gedit ./src/roboAI.c ./src/roboAI.h ./src/roboSoccer.c ./src/imagecapture/imageCapture.c ./src/imagecapture/imageCapture.h &


